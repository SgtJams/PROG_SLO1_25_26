void main()
{}